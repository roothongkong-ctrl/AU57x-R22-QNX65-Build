#ifndef R135_START_OBSERVER_H
#define R135_START_OBSERVER_H
#include <stdint.h>
#include <stddef.h>
/* Read-only snapshot of the exact MU1005 BluetoothServices singleton.
 * The callback must verify the pinned mapped image and readable ranges.
 * A ready snapshot is NOT original-thread, lifetime, pairing or MFi proof.
 * No lock acquisition, no SDK calls, no logging hook, no process launch. */
typedef struct {void *context; int (*certify)(void *); int (*read)(void *,uint32_t,void *,size_t);} R135Reader;
/* 1 observed started, 0 observed not ready, -1 invalid/unreadable/changed. */
int r135_start_snapshot(const R135Reader *);
/* Checked startup plus every pinned native entry word. 1 means observed
 * ready, not lifecycle/owner authorization. No direct fixed-address dereference. */
int r136_native_preflight(const R135Reader *);
#endif
