#include "r135_start_observer.h"
#define OBJ 0x2c2810u
#define GUARD 0x2c2fb8u
#define VPTR 0x2be500u
#define FLAG (OBJ+0x1b0u)
static int rd32(const R135Reader*r,uint32_t a,uint32_t*v){uint8_t b[4];if(r->read(r->context,a,b,4)!=1)return 0;*v=(uint32_t)b[0]|((uint32_t)b[1]<<8)|((uint32_t)b[2]<<16)|((uint32_t)b[3]<<24);return 1;}
static int sample(const R135Reader*r,uint32_t*g,uint32_t*v,uint8_t*f){if(r->certify(r->context)!=1||!rd32(r,GUARD,g))return 0;*v=0;*f=0;if(!(*g&1u))return 1;return rd32(r,OBJ,v)&&r->read(r->context,FLAG,f,1)==1;}
int r135_start_snapshot(const R135Reader*r){uint32_t g1,g2,v1,v2;uint8_t f1,f2;if(!r||!r->certify||!r->read||!sample(r,&g1,&v1,&f1)||!sample(r,&g2,&v2,&f2)||r->certify(r->context)!=1)return -1;if(g1!=g2||v1!=v2||f1!=f2)return -1;if(!(g1&1u))return 0;if(v1!=VPTR||f1>1)return -1;return f1==1;}

#include "native_binding_words.h"
#include "mu1005_rf_abi_words.h"
int r136_native_preflight(const R135Reader *r){
 int st=r135_start_snapshot(r);uint32_t w;
 if(st!=1)return st;
 for(size_t i=0;i<sizeof mu_bt_words/sizeof mu_bt_words[0];i++){
  if(r->certify(r->context)!=1||!rd32(r,mu_bt_words[i][0],&w)||w!=mu_bt_words[i][1])return -1;
 }
 for(size_t i=0;i<sizeof mu_r121_abi_words/sizeof mu_r121_abi_words[0];i++){
  if(r->certify(r->context)!=1||!rd32(r,mu_r121_abi_words[i][0],&w)||w!=mu_r121_abi_words[i][1])return -1;
 }
 return r135_start_snapshot(r);
}
