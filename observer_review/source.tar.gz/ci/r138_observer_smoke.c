/* Actual target loader test of the original-image observer, without OEM binaries. */
#define _POSIX_C_SOURCE 200809L
#include <dlfcn.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <errno.h>
int main(int argc,char **argv){
#ifdef __QNXNTO__
 const char *path=argc>1?argv[1]:"/proc/boot/libau57x_r138_preload_REVIEW.so";
#else
 if(argc<2)return 2;
 const char *path=argv[1];
#endif
 if(argc>3)return 2;
 /* The shared library is deliberately the wrong image for the pinned btstack. */
 if(setenv("AU57X_R138_REVIEW_STOCK",path,1)!=0)return 3;
 void *h=dlopen(path,RTLD_NOW|RTLD_LOCAL);
 if(!h){fprintf(stderr,"R138_DLOPEN_FAIL %s\n",dlerror());return 4;}
 void *sym=dlsym(h,"r138_observation_status");int (*status)(void)=NULL;
 if(!sym||sizeof status!=sizeof sym)return 5;
 memcpy(&status,&sym,sizeof status);
 for(unsigned i=0;i<100;i++){
  int s=status();
  if(s==-1){puts("R138_WRONG_IMAGE_REJECTED_NO_OEM");return 0;}
  if(s!=1){printf("R138_UNEXPECTED_STATE %d\n",s);return 6;}
  struct timespec ts={0,20000000};while(nanosleep(&ts,&ts)!=0){if(errno!=EINTR)return 7;}
 }
 puts("R138_OBSERVER_TIMEOUT");return 8;
 /* Do not dlclose: the observer constructor is process-lifetime resident. */
}
