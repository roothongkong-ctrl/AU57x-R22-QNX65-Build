/* R138 read-only preload integration. Explicit review opt-in only.
 * No registration, patching, process launch, or writes to OEM memory. */
#define _POSIX_C_SOURCE 200809L
#include <sys/types.h>
#include <stdint.h>
#include <pthread.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include "r135_start_observer.h"
#include "sha256.h"
/* status: 0 inactive, 1 running, 2 observed started, -1 failed,
 * -2 bounded wait expired. A status of 2 is never authorization. */
static int state;
int r138_observation_status(void){return __atomic_load_n(&state,__ATOMIC_ACQUIRE);}
#if (defined(__QNXNTO__) && defined(__arm__) && UINTPTR_MAX == UINT32_MAX) || defined(R138_SYNTAX_ONLY)
#define RX_BASE 0x100000u
#define RX_SIZE 0x1b97dcu
#define IMAGE_END 0x508780u
static char stock_path[256];
typedef struct {int as,stock,verified;} Context;
static int read_full(int fd,void *out,size_t n,off_t offset){
 unsigned char *p=out;while(n){ssize_t k=pread(fd,p,n,offset);if(k<0&&errno==EINTR)continue;if(k<=0)return 0;p+=k;n-=(size_t)k;offset+=k;}return 1;
}
static int identity(Context *c){
 static const char pin[]="51ecbd44c3581bd69f01ed5bdc053ba28ccc6fef3bf1bd4c3a8f010898ab0566";
 unsigned char b[4096],m[4096],digest[32];char hex[65];struct stat st;sha256_ctx sha;
 if(fstat(c->stock,&st)||!S_ISREG(st.st_mode)||st.st_size!=1846436)return 0;
 sha256_init(&sha);
 for(off_t off=0;off<st.st_size;){size_t n=(size_t)(st.st_size-off);if(n>sizeof b)n=sizeof b;if(!read_full(c->stock,b,n,off))return 0;sha256_update(&sha,b,n);off+=(off_t)n;}
 sha256_final(&sha,digest);const char *digits="0123456789abcdef";
 for(unsigned i=0;i<32;i++){hex[2*i]=digits[digest[i]>>4];hex[2*i+1]=digits[digest[i]&15];}hex[64]=0;
 if(strcmp(hex,pin))return 0;
 for(uint32_t off=0;off<RX_SIZE;){size_t n=RX_SIZE-off;if(n>sizeof b)n=sizeof b;if(!read_full(c->stock,b,n,off)||!read_full(c->as,m,n,(off_t)(RX_BASE+off))||memcmp(b,m,n))return 0;off+=(uint32_t)n;}return 1;
}
static int certify(void *p){Context *c=p;return c->verified;}
static int read_live(void *p,uint32_t a,void *out,size_t n){Context *c=p;return c->verified&&a>=RX_BASE&&a<IMAGE_END&&n<=IMAGE_END-a&&read_full(c->as,out,n,(off_t)a);}
static void *observe(void *unused){
 (void)unused;Context c={-1,-1,0};int result=-1;
 c.stock=open(stock_path,O_RDONLY);c.as=open("/proc/self/as",O_RDONLY);
 if(c.stock<0||c.as<0||!identity(&c))goto done;
 c.verified=1;R135Reader reader={&c,certify,read_live};result=-2;
 for(unsigned i=0;i<40;i++){
  int s=r135_start_snapshot(&reader);if(s<0){result=-1;break;}
  if(s==1){if(r136_native_preflight(&reader)==1&&identity(&c))result=2;else result=-1;break;}
  struct timespec ts={0,250000000};if(nanosleep(&ts,NULL)&&errno!=EINTR){result=-1;break;}
 }
 done:if(c.as>=0)close(c.as);if(c.stock>=0)close(c.stock);__atomic_store_n(&state,result,__ATOMIC_RELEASE);return NULL;
}
/* Preload resident for the process lifetime. No dlclose while worker runs.
 * This opt-in is not an installer or a proof of safe registration. */
__attribute__((constructor)) static void start(void){
 const char *p=getenv("AU57X_R138_REVIEW_STOCK");if(!p||!*p)return;
 if(*p!='/'||strlen(p)>=sizeof stock_path){__atomic_store_n(&state,-1,__ATOMIC_RELEASE);return;}
 memcpy(stock_path,p,strlen(p)+1);pthread_attr_t a;pthread_t t;
 if(pthread_attr_init(&a)){__atomic_store_n(&state,-1,__ATOMIC_RELEASE);return;}
 if(pthread_attr_setdetachstate(&a,PTHREAD_CREATE_DETACHED)){pthread_attr_destroy(&a);__atomic_store_n(&state,-1,__ATOMIC_RELEASE);return;}
 __atomic_store_n(&state,1,__ATOMIC_RELEASE);
 if(pthread_create(&t,&a,observe,NULL))__atomic_store_n(&state,-1,__ATOMIC_RELEASE);
 pthread_attr_destroy(&a);
}
#endif
